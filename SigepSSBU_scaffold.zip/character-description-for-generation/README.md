# character-description-for-generation

Short, structured descriptions used to generate assets (prompts, refs, constraints).

## Suggested subfolders
- `wip/` for work-in-progress
- `final/` for final, approved assets
- `refs/` for reference images or docs
