# character-png-file

Place exported 2D character PNGs here (transparent backgrounds preferred).

## Suggested subfolders
- `wip/` for work-in-progress
- `final/` for final, approved assets
- `refs/` for reference images or docs
