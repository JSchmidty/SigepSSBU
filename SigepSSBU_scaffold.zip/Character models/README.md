# Character models

Place 3D character models here. Prefer .fbx for rigged meshes; .obj acceptable for static meshes.

## Suggested subfolders
- `wip/` for work-in-progress
- `final/` for final, approved assets
- `refs/` for reference images or docs
